import{h as a}from"./chunk-LZBQAEKV.js";export default a();
